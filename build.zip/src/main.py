import copy
import heapq
import random
import sys
import threading
import time
from F2L.F2L5 import F2L
from OLL.OLL import OLL
from PLL.PLL import PLL
from cross.resolve_cross import resolve_cross
from rubik_class import RubiksCube
from rubik_utils import apply_mouves, clear_mouves
from vizualize import RubixVisualiser, launch_vizualiser
import numpy as np
from OLL.OLL_algos import algos as OLL_algo


def mouve_visualiser(mouves: list[str], visualiser: RubixVisualiser, speed: float):
    time.sleep(1)
    visualiser.SPEED = speed
    for mouve in mouves:
        visualiser.visualizer_mouves[mouve]()
        time.sleep(visualiser.SPEED)


def mix_rubiks(mouves: str, rubik: RubiksCube, visualiser: RubixVisualiser | None = None):
    array_mouves = mouves.split()

    if len(list(filter(lambda mouve: mouve not in list(rubik.mouves.keys()), array_mouves))):
        raise AssertionError('Bad mouve provided')
    if visualiser:
        visualiser.SPEED = 0.02
    for mouve in array_mouves:
        rubik.mouves[mouve]()
        if visualiser:
            visualiser.visualizer_mouves[mouve]()
    return array_mouves


def random_scramble(rubik: RubiksCube, visualiser: RubixVisualiser | None = None):
    test_mouves = list(rubik.mouves.keys())

    if visualiser:
        visualiser.SPEED = 0.02
    mouves_sequence = []
    for _ in range(0, 20):
        mouve = random.choice(test_mouves)
        rubik.mouves[mouve]()
        mouves_sequence.append(mouve)
        if visualiser:
            visualiser.visualizer_mouves[mouve]()
            time.sleep(visualiser.SPEED)

    return mouves_sequence


def resolve_rubik(rubik: RubiksCube, visualiser: RubixVisualiser | None = None):

    rubik_conf = copy.deepcopy(rubik.cube)
    mouves: list | None = None
    i = 0

    mouves = None
    closed_set_cross = set()
    explored_cross = set()

    i = 0

    cross_mouves = None
    mouves2 = None
    cross_conf = None
    explored_F2L = set()

    for _ in range(20):

        cross_mouves_tmp = copy.copy(
            clear_mouves(resolve_cross(rubik, closed_set_cross, None)))
        if (cross_mouves_tmp == None):
            rubik.cube = copy.deepcopy(rubik_conf)
            continue

        if cross_mouves == None or len(cross_mouves_tmp) < len(cross_mouves):
            cross_mouves = cross_mouves_tmp
            cross_ok = copy.deepcopy(rubik.cube)

        # print(len(cross_mouves_tmp))
        # conf = " ".join((np.array(rubik.get_cube_array())).flatten())
        # if conf == cross_conf and len(cross_mouves_tmp) < len(cross_mouves):
        #     cross_mouves = cross_mouves_tmp
        #     rubik.cube = copy.deepcopy(rubik_conf)
        #     i += 1
        #     continue

        # explored = next(
        #     (element for element in explored_cross if element[1] == conf), None)
        # if explored:
        #     rubik.cube = copy.deepcopy(rubik_conf)
        #     i += 1
        #     continue
        # else:
        #     explored_cross.add(tuple((" ".join(cross_mouves_tmp), conf)))

    closed_set_F2L = set()
    for _ in range(1):
        F2L_mouves = copy.copy(
            F2L(rubik, closed_set_F2L, explored_F2L, None))
        if (F2L_mouves == None):
            rubik.cube = copy.deepcopy(cross_ok)
            continue
        if not rubik.check_F2L():
            raise Exception("F2L not OK")

        OLL_mouves = copy.copy(OLL(rubik))
        if not rubik.check_OLL():
            raise Exception("OLL not OK")

        PLL_mouves = copy.copy(PLL(rubik))

        rubik.cube = copy.deepcopy(cross_ok)
        clear_concat = copy.copy(clear_mouves(
            F2L_mouves + OLL_mouves + PLL_mouves))
        apply_mouves(clear_concat, rubik, None, False)

        if not rubik.check_solved():
            rubik.pretty_print()
            raise Exception("PLL not OK")

        mouves_tmp = copy.copy(clear_mouves(
            cross_mouves + clear_concat))
        if mouves == None or len(mouves_tmp) < len(mouves):
            mouves = mouves_tmp

        rubik.cube = copy.deepcopy(cross_ok)
    # rubik.cube = copy.deepcopy(rubik_conf)
    # apply_mouves(mouves, rubik, None, False)
    # rubik.pretty_print()
    rubik.cube = copy.deepcopy(rubik_conf)

    apply_mouves(mouves, rubik, None, False)
   # rubik.pretty_print()
    rubik.soluce_mouves = mouves
   # rubik.pretty_print()
    # print("cross", len(cross_mouves))
    # print("F2L", len(F2L_mouves))
    # print("OLL", len(OLL_mouves))
    # print("PLL", len(PLL_mouves))
    # print(len(rubik.soluce_mouves))

    return

# def resolve_rubik(rubik: RubiksCube, visualiser: RubixVisualiser | None = None):

#     rubik_conf = copy.deepcopy(rubik.cube)
#     mouves: list | None = None
#     i = 0

#     mouves = None
#     closed_set_cross = set()
#     explored_cross = set()

#     i = 0

#     cross_mouves = None
#     mouves2 = None
#     cross_conf = None
#     explored_F2L = set()

#     while i < 1 or mouves == None:

#         cross_mouves_tmp = copy.copy(
#             clear_mouves(resolve_cross(rubik, closed_set_cross, None)))
#         if (cross_mouves_tmp == None):
#             rubik.cube = copy.deepcopy(rubik_conf)
#             i += 1
#             continue

#         # print(len(cross_mouves_tmp))
#         conf = " ".join((np.array(rubik.get_cube_array())).flatten())
#         if conf == cross_conf and len(cross_mouves_tmp) < len(cross_mouves):
#             cross_mouves = cross_mouves_tmp
#             rubik.cube = copy.deepcopy(rubik_conf)
#             i += 1
#             continue

#         explored = next(
#             (element for element in explored_cross if element[1] == conf), None)
#         if explored:
#             rubik.cube = copy.deepcopy(rubik_conf)
#             i += 1
#             continue
#         else:
#             explored_cross.add(tuple((" ".join(cross_mouves_tmp), conf)))

#         cross_ok = copy.deepcopy(rubik.cube)

#         closed_set_F2L = set()
#         for _ in range(1):
#             F2L_mouves = copy.copy(
#                 F2L(rubik, closed_set_F2L, explored_F2L, None))
#             if (F2L_mouves == None):
#                 rubik.cube = copy.deepcopy(cross_ok)
#                 continue
#             if not rubik.check_F2L():
#                 raise Exception("F2L not OK")

#             OLL_mouves = copy.copy(OLL(rubik))
#             if not rubik.check_OLL():
#                 raise Exception("OLL not OK")

#             PLL_mouves = copy.copy(PLL(rubik))

#             rubik.cube = copy.deepcopy(cross_ok)
#             clear_concat = copy.copy(clear_mouves(
#                 F2L_mouves + OLL_mouves + PLL_mouves))
#             # print('len concat', len(concat), " len clean", len(clear_concat))
#             # print(concat)
#             # print(clear_concat)
#             apply_mouves(clear_concat, rubik, None, False)

#             if not rubik.check_solved():
#                 rubik.pretty_print()
#                 raise Exception("PLL not OK")

#             mouves_tmp = copy.copy(clear_mouves(
#                 cross_mouves_tmp + clear_concat))
#             if mouves == None or len(mouves_tmp) < len(mouves):
#                 mouves2 = copy.deepcopy(clear_concat)
#                 cross_mouves = cross_mouves_tmp
#                 cross_conf = conf
#                 mouves = mouves_tmp

#             rubik.cube = copy.deepcopy(cross_ok)
#         # rubik.cube = copy.deepcopy(rubik_conf)
#         # apply_mouves(mouves, rubik, None, False)
#         # rubik.pretty_print()
#         rubik.cube = copy.deepcopy(rubik_conf)

#     apply_mouves(mouves, rubik, None, False)
#    # rubik.pretty_print()
#     rubik.soluce_mouves = mouves
#    # rubik.pretty_print()
#     # print("cross", len(cross_mouves))
#     # print("F2L", len(F2L_mouves))
#     # print("OLL", len(OLL_mouves))
#     # print("PLL", len(PLL_mouves))
#     # print(len(rubik.soluce_mouves))

#     return

    apply_mouves(mouves2, rubik, None, False)
    if not rubik.check_solved():
        rubik.cube = copy.deepcopy(rubik_white_ok_cpy)
        rubik.pretty_print()
        apply_mouves(F2L_mouves_final, rubik, None, False)
        rubik.pretty_print()
        apply_mouves(OLL_mouves_final, rubik, None, False)
        rubik.pretty_print()
        apply_mouves(PLL_mouves_final, rubik, None, False)
        rubik.pretty_print()
        raise Exception('not sorted')
    clear_concat = clear_mouves(cross_mouves + mouves2)
    # clear_concat = copy.copy(cross_mouves) + copy.copy(mouves2)
    if (rubik.check_solved() and ((mouves == None or (cross_mouves != None and len(clear_concat) < len(mouves))))):
        mouves = clear_concat

        rubik.cube = copy.deepcopy(rubik_conf)
        i += 1

    rubik.soluce_mouves = clear_mouves(mouves)

    apply_mouves(rubik.soluce_mouves, rubik, visualiser, False)

# def resolve_rubik(rubik: RubiksCube, visualiser: RubixVisualiser | None = None):

#     rubik_conf = copy.deepcopy(rubik.cube)
#     mouves: list | None = None
#     i = 0

#     explored_cross = set()
#     explored_f2L = set()
#     while i < 20 or mouves == None:
#         cross_mouves = resolve_cross(rubik, None)
#         # print(len(explored_nodes))
#         if cross_mouves == None:
#             rubik.cube = copy.deepcopy(rubik_conf)
#             i += 1
#             continue

#         rubik_white_ok_cpy = copy.deepcopy(rubik.cube)

#         hashed_conf = ""
#         for face in rubik_white_ok_cpy:
#             str_array = "".join(rubik_white_ok_cpy[face].array.flatten())
#             hashed_conf += str(hash(str_array))
#         if hashed_conf in explored_cross:
#             rubik.cube = copy.deepcopy(rubik_conf)
#             continue
#         else:
#             explored_cross.add(hashed_conf)

#         F2L_mouves_final, OLL_mouves_final, PLL_mouves_final = None, None, None
#         mouves2 = None

#         j = 0
#         while j < 3:
#             print(len(explored_f2L))
#             F2L_mouves = F2L(rubik, None)
#             if F2L_mouves == None:
#                 continue

#             hashed_conf = ""
#             for face in rubik.cube:
#                 str_array = "".join(rubik.cube[face].array.flatten())
#                 hashed_conf += str(hash(str_array))
#             if hashed_conf in explored_f2L:
#                 rubik.cube = copy.deepcopy(rubik_white_ok_cpy)
#                 continue
#             else:
#                 explored_f2L.add(hashed_conf)

#             OLL_mouves = OLL(rubik)
#             apply_mouves(OLL_mouves, rubik, None, False)
#             if not rubik.check_OLL():
#                 continue
#             PLL_mouves = PLL(rubik)

#             clear_concat = clear_mouves(F2L_mouves + OLL_mouves + PLL_mouves)
#             # clear_concat = copy.copy(
#             # F2L_mouves) + copy.copy(OLL_mouves) + copy.copy(PLL_mouves)
#             if (mouves2 == None or len(clear_concat) < len(mouves2)):
#                 mouves2 = clear_concat
#                 F2L_mouves_final, OLL_mouves_final, PLL_mouves_final = F2L_mouves, OLL_mouves, PLL_mouves
#             rubik.cube = copy.deepcopy(rubik_white_ok_cpy)
#             j += 1

#         if mouves2 == None:
#             continue
#         apply_mouves(mouves2, rubik, None, False)
#         if not rubik.check_solved():
#             rubik.cube = copy.deepcopy(rubik_white_ok_cpy)
#             rubik.pretty_print()
#             apply_mouves(F2L_mouves_final, rubik, None, False)
#             rubik.pretty_print()
#             apply_mouves(OLL_mouves_final, rubik, None, False)
#             rubik.pretty_print()
#             apply_mouves(PLL_mouves_final, rubik, None, False)
#             rubik.pretty_print()
#             raise Exception('not sorted')
#         clear_concat = clear_mouves(cross_mouves + mouves2)
#        # clear_concat = copy.copy(cross_mouves) + copy.copy(mouves2)
#         if (rubik.check_solved() and ((mouves == None or (cross_mouves != None and len(clear_concat) < len(mouves))))):
#             mouves = clear_concat

#         rubik.cube = copy.deepcopy(rubik_conf)
#         i += 1

#     rubik.soluce_mouves = clear_mouves(mouves)

#     apply_mouves(rubik.soluce_mouves, rubik, visualiser, False)


def get_options(argv: list[str]):
    len = len(argv)
    visualise = False

    i = 1
    while (i < len):
        if (argv[i] == '--visualise' or argv == "--generate"):
            pass


if __name__ == "__main__":
    global mix
    try:

        rubik = RubiksCube()

        # generate_opt, visualiser_opt = get_options(sys.argv)

        if len(sys.argv) != 2:
            raise AssertionError("Bad number of arguments")

        # test_OLL(rubik)
        # sys.exit()
        # mix = mix_rubiks(sys.argv[1], rubik)
        mix = random_scramble(rubik)

        resolve_rubik(rubik, None)

        if (not rubik.check_solved()):
            raise Exception('The rubik is not solved')
        print(' '.join(rubik.soluce_mouves))
        sys.exit(0)

        visualiser = RubixVisualiser()
        mouve_visualiser(mix, visualiser, 0.0)

        thread_visualiser = threading.Thread(
            target=mouve_visualiser, args=[rubik.soluce_mouves, visualiser, 0.04])
        thread_visualiser.start()
        launch_vizualiser()

    except Exception as e:
        print("Error:", e)
        # sys.exit(-2)
        raise (e)

    except KeyboardInterrupt:
        visualiser.close()
        print("Canceled")
sys.exit()
